/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package console_version;

/**
 *
 * @author N TECH
 */
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class MatchManager {
    private Queue<MatchInfo> matchQueue = new LinkedList<>();
    private Scanner sc = new Scanner(System.in);

    // Add Match
    public void addMatch() {
        System.out.print("Enter Team 1: ");
        String team1 = sc.nextLine();

        System.out.print("Enter Team 2: ");
        String team2 = sc.nextLine();

        System.out.print("Enter Venue: ");
        String venue = sc.nextLine();

        System.out.print("Enter Date (e.g., 12-Nov-2025): ");
        String date = sc.nextLine();

        System.out.print("Enter Result (or 'Pending'): ");
        String result = sc.nextLine();

        MatchInfo match = new MatchInfo(team1, team2, venue, date, result);
        matchQueue.add(match);

        System.out.println("Match Added Successfully!\n");
    }

    // Display All Matches
    public void displayMatches() {
        if (matchQueue.isEmpty()) {
            System.out.println("No matches found.\n");
            return;
        }

        System.out.println("Match List:\n");
        for (MatchInfo match : matchQueue) {
            System.out.println(match);
        }
    }

    // Remove First Match
    public void removeMatch() {
        if (matchQueue.isEmpty()) {
            System.out.println("No matches to remove.\n");
            return;
        }

        MatchInfo removed = matchQueue.remove();
        System.out.println("Removed Match ID: " + removed.getMatchId() + "\n");
    }

    // Peek First Match
    public void peekMatch() {
        if (matchQueue.isEmpty()) {
            System.out.println("Queue is empty.\n");
            return;
        }

        System.out.println("First Match in Queue:\n" + matchQueue.peek());
    }

    // Update Match Result
    public void updateMatch() {
    if (matchQueue.isEmpty()) {
        System.out.println("No matches to update.\n");
        return;
    }

    System.out.print("Enter Match ID to Update: ");
    int id = sc.nextInt();
    sc.nextLine(); // clear buffer

    boolean found = false;
    for (MatchInfo match : matchQueue) {
        if (match.getMatchId() == id) {
            found = true;
            System.out.println("What do you want to update?");
            System.out.println("1. Team 1");
            System.out.println("2. Team 2");
            System.out.println("3. Venue");
            System.out.println("4. Date");
            System.out.println("5. Result");
            System.out.print("Enter choice: ");
            int ch = sc.nextInt();
            sc.nextLine();

            switch (ch) {
                case 1:
                    System.out.print("Enter New Team 1: ");
                    match.setTeam1(sc.nextLine());
                    System.out.println("Team 1 Updated!");
                    break;
                case 2:
                    System.out.print("Enter New Team 2: ");
                    match.setTeam2(sc.nextLine());
                    System.out.println("Team 2 Updated!");
                    break;
                case 3:
                    System.out.print("Enter New Venue: ");
                    match.setVenue(sc.nextLine());
                    System.out.println("Venue Updated!");
                    break;
                case 4:
                    System.out.print("Enter New Date: ");
                    match.setDate(sc.nextLine());
                    System.out.println("Date Updated!");
                    break;
                case 5:
                    System.out.print("Enter New Result: ");
                    match.setResult(sc.nextLine());
                    System.out.println("Result Updated!");
                    break;
                default:
                    System.out.println("Invalid Option!");
            }
            break;
        }
    }

    if (!found) {
        System.out.println("Match ID not found.\n");
    }
}
    public Queue<MatchInfo> getQueue() { 
    return matchQueue; 
}

public void setQueue(Queue<MatchInfo> q) { 
    this.matchQueue = q; 
}

}


