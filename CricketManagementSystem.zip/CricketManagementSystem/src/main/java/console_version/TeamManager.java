/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author N TECH
 */
package console_version;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class TeamManager {
    private Queue<Team> teamQueue = new LinkedList<>();
    private Scanner sc = new Scanner(System.in);

    // Add Team
    public void addTeam() {
        System.out.print("Enter Team Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Captain Name: ");
        String captain = sc.nextLine();

        System.out.print("Enter Matches Played: ");
        int matches = sc.nextInt();

        System.out.print("Enter Wins: ");
        int wins = sc.nextInt();
        sc.nextLine(); // clear buffer

        Team team = new Team(name, captain, matches, wins);
        teamQueue.add(team);
        System.out.println("Team added successfully!\n");
    }

    // Display Teams
    public void displayTeams() {
        if (teamQueue.isEmpty()) {
            System.out.println("No teams found.\n");
            return;
        }

        System.out.println("Teams List:\n");
        for (Team team : teamQueue) {
            System.out.println(team);
        }
    }

    // Remove Team (FIFO)
public void removeTeam() {
    if (teamQueue.isEmpty()) {
        System.out.println("No teams to remove.\n");
        return;
    }

    Team removed = teamQueue.remove(); // Automatically removes the first team in queue
    System.out.println("Removed Team: " + removed.getTeamName() + " (ID: " + removed.getTeamId() + ")\n");
}

    // Peek First Team
    public void peekTeam() {
        if (teamQueue.isEmpty()) {
            System.out.println("Queue is empty.\n");
            return;
        }

        System.out.println("First Team in Queue:\n" + teamQueue.peek());
    }

    // Update Team (Choice-Based)
    public void updateTeam(int id) {
        boolean found = false;
        for (Team team : teamQueue) {
            if (team.getTeamId() == id) {
                found = true;

                while (true) {
                    System.out.println("\n--- Update Team Menu ---");
                    System.out.println("1. Team Name");
                    System.out.println("2. Captain Name");
                    System.out.println("3. Matches Played");
                    System.out.println("4. Wins");
                    System.out.println("5. Done");
                    System.out.print("Enter your choice: ");
                    int choice = sc.nextInt();
                    sc.nextLine();

                    switch (choice) {
                        case 1:
                            System.out.print("Enter New Team Name: ");
                            team.setTeamName(sc.nextLine());
                            System.out.println("Team Name Updated!");
                            break;
                        case 2:
                            System.out.print("Enter New Captain Name: ");
                            team.setCaptainName(sc.nextLine());
                            System.out.println("Captain Updated!");
                            break;
                        case 3:
                            System.out.print("Enter New Matches Played: ");
                            team.setMatchesPlayed(sc.nextInt());
                            sc.nextLine();
                            System.out.println("Matches Updated!");
                            break;
                        case 4:
                            System.out.print("Enter New Wins: ");
                            team.setWins(sc.nextInt());
                            sc.nextLine();
                            System.out.println("Wins Updated!");
                            break;
                        case 5:
                            System.out.println("Team update completed!");
                            return;
                        default:
                            System.out.println("Invalid choice! Try again.");
                    }
                }
            }
        }

        if (!found) {
            System.out.println("Team with ID " + id + " not found!");
        }
    }

    public boolean isEmpty() {
        return teamQueue.isEmpty();
    }
    public Queue<Team> getQueue() { 
        return teamQueue; 
    }

    public void setQueue(Queue<Team> q) { 
        this.teamQueue = q; 
    }

}
