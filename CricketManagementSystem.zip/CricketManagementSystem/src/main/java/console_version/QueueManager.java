/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author N TECH
 */
//import console_version.Player;

package console_version;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class QueueManager {
    private Queue<Player> playerQueue = new LinkedList<>();

    // ➕ Add (Enqueue)
    public void enqueue(Player player) {
        playerQueue.add(player);
        System.out.println("Player added successfully!");
    }

    // ➖ Remove (Dequeue)
    public void dequeue() {
        if (playerQueue.isEmpty()) {
            System.out.println("Queue is empty!");
        } else {
            Player removed = playerQueue.remove();
            System.out.println("Removed Player: " + removed.getName());
        }
    }

    // 👁️ Display all players
    public void display() {
        if (playerQueue.isEmpty()) {
            System.out.println("No players to display!");
        } else {
            System.out.println("\nCurrent Players in Queue:");
            for (Player p : playerQueue) {
                System.out.println(p); // Uses Player.toString()
            }
        }
    }

    // 🔄 Update player by ID
    /*public void update(int id, String name, String role, int runs, int wickets,
                       int matches, double average, double strikeRate,
                       double economy, String teamName) {
        boolean found = false;
        for (Player p : playerQueue) {
            if (p.getId() == id) {
                p.setName(name);
                p.setRole(role);
                p.setRuns(runs);
                p.setWickets(wickets);
                p.setMatches(matches);
                p.setAverage(average);
                p.setStrikeRate(strikeRate);
                p.setEconomy(economy);
                p.setTeamName(teamName);

                System.out.println("✅ Player record updated successfully!");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("❌ Player with ID " + id + " not found!");
        }
    }*/
    // Old update method remove or comment out
// public void update(int id, String name, String role, ...)

public void update(int id, Scanner sc) {
    boolean found = false;
    for (Player p : playerQueue) {
        if (p.getId() == id) {
            found = true;

            while (true) {
                System.out.println("\n--- Update Player Menu ---");
                System.out.println("1. Name");
                System.out.println("2. Role");
                System.out.println("3. Runs");
                System.out.println("4. Wickets");
                System.out.println("5. Matches");
                System.out.println("6. Average");
                System.out.println("7. Strike Rate");
                System.out.println("8. Economy");
                System.out.println("9. Team Name");
                System.out.println("10. Done");
                System.out.print("Enter your choice: ");
                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {
                    case 1:
                        System.out.print("Enter New Name: ");
                        p.setName(sc.nextLine());
                        System.out.println("Name Updated!");
                        break;
                    case 2:
                        System.out.print("Enter New Role: ");
                        p.setRole(sc.nextLine());
                        System.out.println("Role Updated!");
                        break;
                    case 3:
                        System.out.print("Enter New Runs: ");
                        p.setRuns(sc.nextInt());
                        sc.nextLine();
                        System.out.println("Runs Updated!");
                        break;
                    case 4:
                        System.out.print("Enter New Wickets: ");
                        p.setWickets(sc.nextInt());
                        sc.nextLine();
                        System.out.println("Wickets Updated!");
                        break;
                    case 5:
                        System.out.print("Enter New Matches: ");
                        p.setMatches(sc.nextInt());
                        sc.nextLine();
                        System.out.println("Matches Updated!");
                        break;
                    case 6:
                        System.out.print("Enter New Average: ");
                        p.setAverage(sc.nextDouble());
                        sc.nextLine();
                        System.out.println("Average Updated!");
                        break;
                    case 7:
                        System.out.print("Enter New Strike Rate: ");
                        p.setStrikeRate(sc.nextDouble());
                        sc.nextLine();
                        System.out.println("Strike Rate Updated!");
                        break;
                    case 8:
                        System.out.print("Enter New Economy: ");
                        p.setEconomy(sc.nextDouble());
                        sc.nextLine();
                        System.out.println("Economy Updated!");
                        break;
                    case 9:
                        System.out.print("Enter New Team Name: ");
                        p.setTeamName(sc.nextLine());
                        System.out.println("Team Name Updated!");
                        break;
                    case 10:
                        System.out.println("Player update completed!");
                        return;
                    default:
                        System.out.println("Invalid choice! Try again.");
                }
            }
        }
    }
    if (!found) {
        System.out.println("Player with ID " + id + " not found!");
    }
}


    // 👀 Peek (view first player in queue)
    public void peek() {
        if (playerQueue.isEmpty()) {
            System.out.println("Queue is empty!");
        } else {
            System.out.println("\nFirst Player in Queue:");
            System.out.println(playerQueue.peek());
        }
    }

    // ✅ Check if queue is empty
    public boolean isEmpty() {
        return playerQueue.isEmpty();
    }
    // Getter for file handling
    public Queue<Player> getQueue() { return playerQueue; }
    public void setQueue(Queue<Player> queue) { this.playerQueue = queue; }
}
